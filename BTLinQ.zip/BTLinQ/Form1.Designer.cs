﻿
namespace BTLinQ
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMaSP = new System.Windows.Forms.TextBox();
            this.txtTenSP = new System.Windows.Forms.TextBox();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.txtXuatXu = new System.Windows.Forms.TextBox();
            this.dtpNgayHetHan = new System.Windows.Forms.DateTimePicker();
            this.btnLuuSP = new System.Windows.Forms.Button();
            this.btnXoaSP = new System.Windows.Forms.Button();
            this.dgvTimKiemSP = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtGiaMax = new System.Windows.Forms.TextBox();
            this.txtGiaMin = new System.Windows.Forms.TextBox();
            this.btnSPDonGiaAB = new System.Windows.Forms.Button();
            this.btnSPQuaHan = new System.Windows.Forms.Button();
            this.btnSPNhatBan = new System.Windows.Forms.Button();
            this.btnSPCaoNhat = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dgvSanPham = new System.Windows.Forms.DataGridView();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtXuatXuXoa = new System.Windows.Forms.TextBox();
            this.XoaQuaHan = new System.Windows.Forms.Button();
            this.btnXoaToanBo = new System.Windows.Forms.Button();
            this.btnKiemTraQuaHan = new System.Windows.Forms.Button();
            this.btnXoaTheoXuatXu = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTimKiemSP)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSanPham)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã SP: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên SP:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(26, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "Số lượng:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(26, 164);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Đơn giá:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(26, 204);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Xuất xứ:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(26, 244);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "Ngày hết hạn:";
            // 
            // txtMaSP
            // 
            this.txtMaSP.Location = new System.Drawing.Point(153, 39);
            this.txtMaSP.Name = "txtMaSP";
            this.txtMaSP.Size = new System.Drawing.Size(263, 23);
            this.txtMaSP.TabIndex = 6;
            // 
            // txtTenSP
            // 
            this.txtTenSP.Location = new System.Drawing.Point(153, 79);
            this.txtTenSP.Name = "txtTenSP";
            this.txtTenSP.Size = new System.Drawing.Size(263, 23);
            this.txtTenSP.TabIndex = 7;
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Location = new System.Drawing.Point(153, 119);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(263, 23);
            this.txtSoLuong.TabIndex = 8;
            // 
            // txtDonGia
            // 
            this.txtDonGia.Location = new System.Drawing.Point(153, 159);
            this.txtDonGia.Name = "txtDonGia";
            this.txtDonGia.Size = new System.Drawing.Size(263, 23);
            this.txtDonGia.TabIndex = 9;
            // 
            // txtXuatXu
            // 
            this.txtXuatXu.Location = new System.Drawing.Point(153, 199);
            this.txtXuatXu.Name = "txtXuatXu";
            this.txtXuatXu.Size = new System.Drawing.Size(263, 23);
            this.txtXuatXu.TabIndex = 10;
            // 
            // dtpNgayHetHan
            // 
            this.dtpNgayHetHan.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgayHetHan.Location = new System.Drawing.Point(154, 239);
            this.dtpNgayHetHan.Name = "dtpNgayHetHan";
            this.dtpNgayHetHan.Size = new System.Drawing.Size(262, 23);
            this.dtpNgayHetHan.TabIndex = 11;
            // 
            // btnLuuSP
            // 
            this.btnLuuSP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(201)))), ((int)(((byte)(104)))), ((int)(((byte)(104)))));
            this.btnLuuSP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnLuuSP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLuuSP.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLuuSP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(244)))), ((int)(((byte)(234)))));
            this.btnLuuSP.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnLuuSP.Location = new System.Drawing.Point(172, 282);
            this.btnLuuSP.Name = "btnLuuSP";
            this.btnLuuSP.Size = new System.Drawing.Size(84, 23);
            this.btnLuuSP.TabIndex = 12;
            this.btnLuuSP.Text = "Lưu SP  ";
            this.btnLuuSP.UseVisualStyleBackColor = false;
            this.btnLuuSP.Click += new System.EventHandler(this.btnLuuSP_Click);
            // 
            // btnXoaSP
            // 
            this.btnXoaSP.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(201)))), ((int)(((byte)(104)))), ((int)(((byte)(104)))));
            this.btnXoaSP.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnXoaSP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnXoaSP.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaSP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(244)))), ((int)(((byte)(234)))));
            this.btnXoaSP.Location = new System.Drawing.Point(320, 282);
            this.btnXoaSP.Name = "btnXoaSP";
            this.btnXoaSP.Size = new System.Drawing.Size(84, 23);
            this.btnXoaSP.TabIndex = 13;
            this.btnXoaSP.Text = "Xóa SP";
            this.btnXoaSP.UseVisualStyleBackColor = false;
            this.btnXoaSP.Click += new System.EventHandler(this.btnXoaSP_Click);
            // 
            // dgvTimKiemSP
            // 
            this.dgvTimKiemSP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTimKiemSP.Location = new System.Drawing.Point(16, 104);
            this.dgvTimKiemSP.Name = "dgvTimKiemSP";
            this.dgvTimKiemSP.RowHeadersWidth = 51;
            this.dgvTimKiemSP.RowTemplate.Height = 24;
            this.dgvTimKiemSP.Size = new System.Drawing.Size(810, 201);
            this.dgvTimKiemSP.TabIndex = 14;
            this.dgvTimKiemSP.Click += new System.EventHandler(this.btnSPCaoNhat_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox1.Controls.Add(this.txtGiaMax);
            this.groupBox1.Controls.Add(this.dgvTimKiemSP);
            this.groupBox1.Controls.Add(this.txtGiaMin);
            this.groupBox1.Controls.Add(this.btnSPDonGiaAB);
            this.groupBox1.Controls.Add(this.btnSPQuaHan);
            this.groupBox1.Controls.Add(this.btnSPNhatBan);
            this.groupBox1.Controls.Add(this.btnSPCaoNhat);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.groupBox1.Location = new System.Drawing.Point(500, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(838, 327);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chọn chức năng tìm kiếm";
            // 
            // txtGiaMax
            // 
            this.txtGiaMax.Location = new System.Drawing.Point(766, 29);
            this.txtGiaMax.Multiline = true;
            this.txtGiaMax.Name = "txtGiaMax";
            this.txtGiaMax.Size = new System.Drawing.Size(59, 53);
            this.txtGiaMax.TabIndex = 5;
            this.txtGiaMax.UseWaitCursor = true;
            // 
            // txtGiaMin
            // 
            this.txtGiaMin.Location = new System.Drawing.Point(699, 29);
            this.txtGiaMin.Multiline = true;
            this.txtGiaMin.Name = "txtGiaMin";
            this.txtGiaMin.Size = new System.Drawing.Size(59, 53);
            this.txtGiaMin.TabIndex = 4;
            this.txtGiaMin.UseWaitCursor = true;
            // 
            // btnSPDonGiaAB
            // 
            this.btnSPDonGiaAB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(223)))), ((int)(((byte)(161)))));
            this.btnSPDonGiaAB.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSPDonGiaAB.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnSPDonGiaAB.Location = new System.Drawing.Point(526, 29);
            this.btnSPDonGiaAB.Name = "btnSPDonGiaAB";
            this.btnSPDonGiaAB.Size = new System.Drawing.Size(166, 53);
            this.btnSPDonGiaAB.TabIndex = 3;
            this.btnSPDonGiaAB.Text = "Xuất các SP có đơn giá [a…b]";
            this.btnSPDonGiaAB.UseVisualStyleBackColor = false;
            this.btnSPDonGiaAB.UseWaitCursor = true;
            this.btnSPDonGiaAB.Click += new System.EventHandler(this.btnSPDonGiaAB_Click);
            // 
            // btnSPQuaHan
            // 
            this.btnSPQuaHan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(223)))), ((int)(((byte)(161)))));
            this.btnSPQuaHan.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSPQuaHan.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnSPQuaHan.Location = new System.Drawing.Point(308, 29);
            this.btnSPQuaHan.Name = "btnSPQuaHan";
            this.btnSPQuaHan.Size = new System.Drawing.Size(161, 53);
            this.btnSPQuaHan.TabIndex = 2;
            this.btnSPQuaHan.Text = "Xuất toàn bộ SP quá hạn";
            this.btnSPQuaHan.UseVisualStyleBackColor = false;
            this.btnSPQuaHan.UseWaitCursor = true;
            this.btnSPQuaHan.Click += new System.EventHandler(this.btnSPQuaHan_Click);
            // 
            // btnSPNhatBan
            // 
            this.btnSPNhatBan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(223)))), ((int)(((byte)(161)))));
            this.btnSPNhatBan.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSPNhatBan.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnSPNhatBan.Location = new System.Drawing.Point(165, 29);
            this.btnSPNhatBan.Name = "btnSPNhatBan";
            this.btnSPNhatBan.Size = new System.Drawing.Size(136, 53);
            this.btnSPNhatBan.TabIndex = 1;
            this.btnSPNhatBan.Text = "1 SP từ Nhật Bản";
            this.btnSPNhatBan.UseVisualStyleBackColor = false;
            this.btnSPNhatBan.UseWaitCursor = true;
            this.btnSPNhatBan.Click += new System.EventHandler(this.btnSPNhatBan_Click);
            // 
            // btnSPCaoNhat
            // 
            this.btnSPCaoNhat.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(223)))), ((int)(((byte)(161)))));
            this.btnSPCaoNhat.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSPCaoNhat.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnSPCaoNhat.Location = new System.Drawing.Point(19, 29);
            this.btnSPCaoNhat.Name = "btnSPCaoNhat";
            this.btnSPCaoNhat.Size = new System.Drawing.Size(140, 53);
            this.btnSPCaoNhat.TabIndex = 0;
            this.btnSPCaoNhat.Text = "1 SP có ĐG cao nhất";
            this.btnSPCaoNhat.UseVisualStyleBackColor = false;
            this.btnSPCaoNhat.UseWaitCursor = true;
            this.btnSPCaoNhat.Click += new System.EventHandler(this.btnSPCaoNhat_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnLuuSP);
            this.groupBox2.Controls.Add(this.btnXoaSP);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.dtpNgayHetHan);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtXuatXu);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtDonGia);
            this.groupBox2.Controls.Add(this.txtMaSP);
            this.groupBox2.Controls.Add(this.txtSoLuong);
            this.groupBox2.Controls.Add(this.txtTenSP);
            this.groupBox2.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(30, 40);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(440, 327);
            this.groupBox2.TabIndex = 16;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Nhập thông tin sản phẩm";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.dgvSanPham);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(30, 389);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1308, 238);
            this.groupBox3.TabIndex = 17;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Danh sách sản phẩm sau khi nhập";
            // 
            // dgvSanPham
            // 
            this.dgvSanPham.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSanPham.Location = new System.Drawing.Point(18, 22);
            this.dgvSanPham.Name = "dgvSanPham";
            this.dgvSanPham.RowHeadersWidth = 51;
            this.dgvSanPham.RowTemplate.Height = 24;
            this.dgvSanPham.Size = new System.Drawing.Size(884, 210);
            this.dgvSanPham.TabIndex = 2;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtXuatXuXoa);
            this.groupBox4.Controls.Add(this.XoaQuaHan);
            this.groupBox4.Controls.Add(this.btnXoaToanBo);
            this.groupBox4.Controls.Add(this.btnKiemTraQuaHan);
            this.groupBox4.Controls.Add(this.btnXoaTheoXuatXu);
            this.groupBox4.Location = new System.Drawing.Point(915, 21);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(381, 211);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Chọn thao tác";
            this.groupBox4.Enter += new System.EventHandler(this.groupBox4_Enter);
            // 
            // txtXuatXuXoa
            // 
            this.txtXuatXuXoa.Location = new System.Drawing.Point(200, 33);
            this.txtXuatXuXoa.Multiline = true;
            this.txtXuatXuXoa.Name = "txtXuatXuXoa";
            this.txtXuatXuXoa.Size = new System.Drawing.Size(174, 48);
            this.txtXuatXuXoa.TabIndex = 4;
            // 
            // XoaQuaHan
            // 
            this.XoaQuaHan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(172)))), ((int)(((byte)(181)))));
            this.XoaQuaHan.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.XoaQuaHan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(244)))), ((int)(((byte)(234)))));
            this.XoaQuaHan.Location = new System.Drawing.Point(194, 144);
            this.XoaQuaHan.Name = "XoaQuaHan";
            this.XoaQuaHan.Size = new System.Drawing.Size(181, 53);
            this.XoaQuaHan.TabIndex = 3;
            this.XoaQuaHan.Text = "Xóa toàn bộ SP quá hạn trong kho";
            this.XoaQuaHan.UseVisualStyleBackColor = false;
            this.XoaQuaHan.Click += new System.EventHandler(this.XoaQuaHan_Click);
            // 
            // btnXoaToanBo
            // 
            this.btnXoaToanBo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(172)))), ((int)(((byte)(181)))));
            this.btnXoaToanBo.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaToanBo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(244)))), ((int)(((byte)(234)))));
            this.btnXoaToanBo.Location = new System.Drawing.Point(21, 144);
            this.btnXoaToanBo.Name = "btnXoaToanBo";
            this.btnXoaToanBo.Size = new System.Drawing.Size(165, 53);
            this.btnXoaToanBo.TabIndex = 2;
            this.btnXoaToanBo.Text = "Xóa toàn bộ SP trong kho";
            this.btnXoaToanBo.UseVisualStyleBackColor = false;
            this.btnXoaToanBo.Click += new System.EventHandler(this.btnXoaToanBo_Click);
            // 
            // btnKiemTraQuaHan
            // 
            this.btnKiemTraQuaHan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(172)))), ((int)(((byte)(181)))));
            this.btnKiemTraQuaHan.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKiemTraQuaHan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(244)))), ((int)(((byte)(234)))));
            this.btnKiemTraQuaHan.Location = new System.Drawing.Point(21, 87);
            this.btnKiemTraQuaHan.Name = "btnKiemTraQuaHan";
            this.btnKiemTraQuaHan.Size = new System.Drawing.Size(353, 51);
            this.btnKiemTraQuaHan.TabIndex = 1;
            this.btnKiemTraQuaHan.Text = "Kiểm tra kho có sản phẩm quá hạn hay không";
            this.btnKiemTraQuaHan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKiemTraQuaHan.UseVisualStyleBackColor = false;
            this.btnKiemTraQuaHan.Click += new System.EventHandler(this.btnKiemTraQuaHan_Click);
            // 
            // btnXoaTheoXuatXu
            // 
            this.btnXoaTheoXuatXu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(126)))), ((int)(((byte)(172)))), ((int)(((byte)(181)))));
            this.btnXoaTheoXuatXu.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaTheoXuatXu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(244)))), ((int)(((byte)(234)))));
            this.btnXoaTheoXuatXu.Location = new System.Drawing.Point(21, 33);
            this.btnXoaTheoXuatXu.Name = "btnXoaTheoXuatXu";
            this.btnXoaTheoXuatXu.Size = new System.Drawing.Size(172, 48);
            this.btnXoaTheoXuatXu.TabIndex = 0;
            this.btnXoaTheoXuatXu.Text = "Xóa SP theo xuất xứ bất kì";
            this.btnXoaTheoXuatXu.UseVisualStyleBackColor = false;
            this.btnXoaTheoXuatXu.Click += new System.EventHandler(this.btnXoaTheoXuatXu_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1357, 639);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "LINQ to OBJECT - Quản lí sản phẩm";
            ((System.ComponentModel.ISupportInitialize)(this.dgvTimKiemSP)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSanPham)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMaSP;
        private System.Windows.Forms.TextBox txtTenSP;
        private System.Windows.Forms.TextBox txtSoLuong;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.TextBox txtXuatXu;
        private System.Windows.Forms.DateTimePicker dtpNgayHetHan;
        private System.Windows.Forms.Button btnLuuSP;
        private System.Windows.Forms.Button btnXoaSP;
        private System.Windows.Forms.DataGridView dgvTimKiemSP;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSPDonGiaAB;
        private System.Windows.Forms.Button btnSPQuaHan;
        private System.Windows.Forms.Button btnSPNhatBan;
        private System.Windows.Forms.Button btnSPCaoNhat;
        private System.Windows.Forms.TextBox txtGiaMax;
        private System.Windows.Forms.TextBox txtGiaMin;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dgvSanPham;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button XoaQuaHan;
        private System.Windows.Forms.Button btnXoaToanBo;
        private System.Windows.Forms.Button btnKiemTraQuaHan;
        private System.Windows.Forms.Button btnXoaTheoXuatXu;
        private System.Windows.Forms.TextBox txtXuatXuXoa;
    }
}

